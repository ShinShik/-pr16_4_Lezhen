﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pr16_4_Lezhen
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void listBoxNotSort_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void listBoxSort_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {         
            StreamReader sr = File.OpenText("txt.txt");
            List<string> countries = new List<string>();
            if (File.Exists("txt.txt"))
            {
                
                while (!sr.EndOfStream)
                {
                    string str = sr.ReadLine();
                    countries.Add(str);
                }                
            }
            else
            {
                MessageBox.Show("Файл не найден");
            }
            sr.Close();

            foreach (string country in countries)
            {
                listBoxNotSort.Items.Add(country);
            }

            var sortedCountries = countries
            .Where(c => double.Parse(c.Split(' ')[1]) > 104000000)
            .OrderBy(c => c.Length)
            .ThenBy(c => c.Split(' ')[0]);

            foreach (var country in sortedCountries)
            {
                listBoxSort.Items.Add(country);
            }
        }
    }
}
